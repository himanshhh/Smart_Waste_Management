# trash sorting > 2024-09-15 12:08am
https://universe.roboflow.com/jawads-workspace/trash-sorting-037nw

Provided by a Roboflow user
License: CC BY 4.0

